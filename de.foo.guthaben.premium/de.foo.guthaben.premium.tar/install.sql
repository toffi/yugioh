ALTER TABLE wcf1_group ADD groupYears TEXT NOT NULL;

ALTER TABLE wcf1_user_to_groups ADD premiumEndTime INT(10) NOT NULL;