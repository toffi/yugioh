<?php
// wcf imports
require_once(WCF_DIR.'lib/action/AbstractAction.class.php');

class GuthabenStatementDeleteAction extends AbstractAction {
	public $logID = 0;
	public $userID = 0;
    public $user = null;
	
	/**
	 * @see Action::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		if(isset($_GET['logID'])) $this->logID = intval($_GET['logID']);
		if(isset($_GET['userID'])) $this->userID = intval($_GET['userID']);

        $this->user = new User($this->userID);
		if(!$this->user->userID) {
			throw new IllegalLinkException();
		}
	}
	
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		parent::execute();

		$sql = "DELETE	
                FROM    wcf".WCF_N."_guthaben_log
                WHERE 	logID = ".$this->logID;
		WCF::getDB()->sendQuery($sql);
        
		$this->executed();
		
		// forward to list page
		HeaderUtil::redirect('index.php?page=GuthabenStatement&userID='.$this->userID.'&packageID='.PACKAGE_ID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>