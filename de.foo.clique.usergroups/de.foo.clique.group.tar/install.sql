ALTER TABLE wcf1_clique
 ADD groupID int(10) unsigned NOT NULL DEFAULT 0;