<?php
// wcf imports
if (!defined('NO_IMPORTS')) {
	require_once(WCF_DIR.'lib/data/DatabaseObject.class.php');
}

class Event extends DatabaseObject {
	protected $sqlJoins = '';
	protected $sqlSelects = '';
	protected $sqlGroupBy = '';

	public function __construct($eventID, $row = null, $eventName = null) {
		// set sql join to user_data table
		$this->sqlSelects .= 'event.*,'; 
		
		// execute sql statement
		$sqlCondition = '';
		if ($eventID !== null) {
			$sqlCondition = "event.eventID = ".$eventID;
		}
		else if ($eventName !== null) {
			$sqlCondition = "event.name = '".escapeString($eventName)."'";
		}
		
		if (!empty($sqlCondition)) {
			$sql = "SELECT 	".$this->sqlSelects."
					event.*
				FROM 	events eventName
					".$this->sqlJoins."
				WHERE 	".$sqlCondition.
					$this->sqlGroupBy;
			$row = WCF::getDB()->getFirstRow($sql);
		}
		
		// handle result set
		parent::__construct($row);
	}
	
	/**
	 * @see DatabaseObject::handleData()
	 */
	protected function handleData($data) {
		parent::handleData($data);
		if (!$this->eventID) $this->data['eventID'] = 0;
	}
}
?>