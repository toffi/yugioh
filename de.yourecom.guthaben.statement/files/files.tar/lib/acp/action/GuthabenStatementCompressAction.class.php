<?php
// wcf imports
require_once(WCF_DIR.'lib/action/AbstractAction.class.php');

class GuthabenStatementCompressAction extends AbstractAction {
	public $userID = 0;
	
	/**
	 * @see Action::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_GET['userID'])) $this->userID = intval($_GET['userID']);
	}
	
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		parent::execute();
		
		// disable avatar
		require_once(WCF_DIR.'lib/data/user/User.class.php');
		$user = new User($this->userID);	
		if (!$user->userID) {
			throw new IllegalLinkException();
		}
		
		Guthaben::compressLog($user);

		$this->executed();
		
		// forward to list page
		HeaderUtil::redirect('index.php?page=GuthabenStatement&userID='.$this->userID.'&packageID='.PACKAGE_ID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>