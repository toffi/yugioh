<?php
require_once(WCF_DIR.'lib/action/AbstractAction.class.php');

class DevPackagesDownloadAction extends AbstractAction {
    public $package = '';
    public $downloadDir = '';

	/**
	 * @see Action::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_GET['package'])) $this->package = StringUtil::trim($_GET['package']);
        
        $this->downloadDir = WCF_DIR.'packages/';
        
		if (!file_exists($this->downloadDir.$this->package)) {
			throw new IllegalLinkException();
		}
	}
	
	/**
	 * @see AbstractAction::executed()
	 */
	public function execute() {
		parent::execute();
		
        unlink($this->downloadDir.$this->package);
        
        $this->executed();
        
		// forward to list page
		HeaderUtil::redirect('index.php?page=DevPackagesDownload&packageID='.PACKAGE_ID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>