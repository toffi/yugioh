<?php
// wcf imports
require_once(WCF_DIR.'lib/system/event/EventListener.class.php');

/**
 * @author	$foo
 * @license	>Creative Commons Namensnennung 3.0 Deutschland License
 * @package	de.foo.clique
 */
class ShoutboxUserLockListener implements EventListener {

	public function execute($eventObj, $className, $eventName){
 		try {
			if (WCF::getUser()->shoutboxLock == 1) {
				throw new NamedUserException(WCF::getLanguage()->get('wcf.shoutbox.entry.error.user.lock'));
			}
		}
		catch (UserException $e) {
			// show errors in a readable way
			if (empty($_REQUEST['ajax'])) {
				throw $e;
			}
			else {
				@header('HTTP/1.0 403 Forbidden');
				echo $e->getMessage();
				exit;
			}
        }
	}
}
?>