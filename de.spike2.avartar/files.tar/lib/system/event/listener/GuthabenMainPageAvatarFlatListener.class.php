<?php
require_once(WCF_DIR.'lib/system/event/EventListener.class.php');
require_once(WCF_DIR.'lib/util/Guthaben.class.php');

/**
 * Buy new avartar
 *
 * @author $foo
 * @license LGPL
 * @package de.spike2.avartar
 */

class GuthabenMainPageAvatarFlatListener implements EventListener {

	/**
	 * @see Action::execute()
	 */
	public function execute($eventObj, $className, $eventName) {
		if (!GUTHABEN_ENABLE_GLOBAL || WCF::getUser()->userID == 0 || WCF::getUser()->avatarFlat == 1) return;
print_r($eventObj);die;
	}
}
?>