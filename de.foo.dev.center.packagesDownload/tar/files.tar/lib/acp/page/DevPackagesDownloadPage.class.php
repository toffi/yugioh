<?php
require_once(WCF_DIR.'lib/page/SortablePage.class.php');

class DevPackagesDownloadPage extends SortablePage {
	// system
	public $templateName = 'devPackagesDownload';
	public $defaultSortField = 'bbcodeTag';

    // DevPackagesDownloadPage
    public $downloadDir = '';
    public $files = NULL;

	/**
	 * @see Page::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		$this->downloadDir = WCF_DIR.'packages/';
	}
	
	/**
	 * @see Page::readData()
	 */
	public function readData() {
		parent::readData();
		
		$this->readDir();
	}
	
	/**
	 * Gets a list of bbcodes.
	 */
	protected function readDir() {
        $handle = opendir($this->downloadDir);
        
        while ($file = readdir($handle)) {
            if(file_exists($this->downloadDir.$file) && !is_dir($this->downloadDir.$file)) {
                 $this->files[] = array('file' => $file,
                                        'fileDir' => RELATIVE_WCF_DIR.'packages/'.$file,
                                        'fileSize' => $this->byteConvert(filesize($this->downloadDir.$file)),
                                        'fileTime' => filemtime($this->downloadDir.$file)
                                    );
            }
        }
        closedir($handle);
	}
	
	/**
	 * @see Page::assignVariables()
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'files' => $this->files
		));
	}
	
	/**
	 * @see Page::show()
	 */
	public function show() {
		// enable menu item
		WCFACP::getMenu()->setActiveMenuItem('wcf.acp.menu.link.dev.packagesDownload');
		
		parent::show();
	}

	/**
	 * @see Page::byteConvert()
	 */
    public function byteConvert($bytes) {
        if($bytes > pow(2,10)) {
            if($bytes > pow(2,20)) {
                $size = number_format(($bytes / pow(2,20)), 2);
                $size .= " MB";
                return $size;
            }
            else {
                $size = number_format(($bytes / pow(2,10)), 2);
                $size .= " KB";
                return $size;
            }
        }
        else {
            $size = (string) $bytes . " Bytes";
            return $size;
        }
    }
}
?>