ALTER TABLE `events` CHANGE `name` `eventName` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `events` CHANGE `name_abbreviation` `nameAbbreviation` VARCHAR( 10 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `events` DROP `calender;
ALTER TABLE `events` CHANGE `officialEvent` `officialEvent` TINYINT( 1 ) NOT NULL DEFAULT '0';
ALTER TABLE `events` CHANGE `id` `eventID` INT( 11 ) NOT NULL AUTO_INCREMENT;
ALTER TABLE `events_paarungen` CHANGE `event_ID` `eventID` INT( 11 ) NOT NULL;
ALTER TABLE `events_team` CHANGE `event_id` `eventID` INT( 11 ) NOT NULL;
ALTER TABLE `events_user` CHANGE `event_id` `eventID` INT( 11 ) NOT NULL;
ALTER TABLE `events_user` CHANGE `user_ID` `userID` INT( 11 ) NOT NULL;
ALTER TABLE `events` CHANGE `current_gameday` `currentGameday` INT( 10 ) NOT NULL;
ALTER TABLE `events_paarungen` CHANGE `scoreID_2` `scoreID2` VARCHAR( 1 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0';

ALTER TABLE `events_user`
  DROP `rates`,
  DROP `S_0`,
  DROP `s`,
  DROP `U`,
  DROP `N_0`,
  DROP `n`;
  
ALTER TABLE `events` DROP `participants_final;
ALTER TABLE `events` DROP `group_participants`;
ALTER TABLE `events` DROP `group_final`;
ALTER TABLE `events` ADD `totalRanking` TINYINT( 0 ) NOT NULL;