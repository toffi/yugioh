<?php
// wcf imports
require_once(WCF_DIR.'lib/system/event/EventListener.class.php');

class GuthabenStatementListener implements EventListener {

	public function execute($eventObj, $className, $eventName) {
    	WCF::getTPL()->append(array(
			'additionalLargeButtons' => '<li><a href="index.php?page=GuthabenStatement&amp;userID='.$eventObj->userID.'&amp;packageID='.PACKAGE_ID.SID_ARG_2ND.'"><img src="'.RELATIVE_WCF_DIR.'icon/guthabenLogM.png" alt="" /> <span>'.WCF::getLanguage()->get('wcf.guthaben.statement').'</span></a></li>'
		));
	}
}
?>