<?php
// wcf imports
require_once(WCF_DIR.'lib/page/SortablePage.class.php');

class GuthabenStatementPage extends SortablePage {
	public $templateName = 'guthabenStatement';
    public $defaultSortField = 'logID';
    public $itemsPerPage = 30;
    public $defaultSortOrder = 'DESC';
    
    public $userID = 0;
    public $money = 0;
    public $statements = NULL;
	
	/**
	 * @see Page::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_GET['userID'])) $this->userID = intval($_GET['userID']);
        $user = new User($this->userID);
		if(!$user->userID) {
			throw new IllegalLinkException();
		}
        $this->money = $user->getUserOption('guthaben');
	}
	
	/**
	 * @see SortablePage::validateSortField()
	 */
	public function validateSortField() {
		parent::validateSortField();
		
		switch ($this->sortField) {
			case 'logID':
            case 'langvar':
			case 'guthaben':
			case 'time': break;
			default: $this->sortField = $this->defaultSortField;
		}
	}
	
	/**
	 * @see MultipleLinkPage::countItems()
	 */
	public function countItems() {
		parent::countItems();
		
		$sql = "SELECT	COUNT(*) AS count
			FROM	wcf".WCF_N."_guthaben_log
            WHERE userID = ".$this->userID;
		$row = WCF::getDB()->getFirstRow($sql);
		return $row['count'];
	}
	
	/**
	 * @see Page::readData()
	 */
	public function readData() {
		parent::readData();
		
		$this->readStatements();
	}
	
	/**
	 * @see Page::assignVariables()
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'statements' => $this->statements,
            'userID' => $this->userID,
            'money' => $this->money
		));
	}
	
	/**
	 * @see Page::show()
	 */
	public function show() {
		// enable menu item
		WCFACP::getMenu()->setActiveMenuItem('wcf.acp.menu.link.user.management');
		
		// check permission
		//WCF::getUser()->checkPermission(array('admin.language.canEditLanguage', 'admin.language.canDeleteLanguage'));
		
		parent::show();
	}
	
	/**
	 * Gets a list of statements.
	 */
	protected function readStatements() {
		if ($this->items) {
			$sql = "SELECT	*
				FROM		wcf".WCF_N."_guthaben_log
                WHERE userID = ".$this->userID."
				ORDER BY	".$this->sortField." ".$this->sortOrder;
			$result = WCF::getDB()->sendQuery($sql, $this->itemsPerPage, ($this->pageNo - 1) * $this->itemsPerPage);
			while ($row = WCF::getDB()->fetchArray($result)) {
				$this->statements[] = $row;
			}
		}
	}
}
?>