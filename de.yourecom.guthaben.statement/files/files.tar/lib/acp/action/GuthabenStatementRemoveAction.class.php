<?php
// wcf imports
require_once(WCF_DIR.'lib/acp/action/GuthabenStatementDeleteAction.class.php');

class GuthabenStatementRemoveAction extends GuthabenStatementDeleteAction {
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		AbstractAction::execute();

		$sql = "SELECT *
                FROM wcf".WCF_N."_guthaben_log
                WHERE 	logID = ".$this->logID;
        $result = WCF::getDB()->getFirstRow($sql);
        
        if($result['guthaben'] > 0) {
            Guthaben::sub($result['guthaben'], 'wcf.guthaben.statement.remove.text', $result['logID'], '', $this->user, true);
        }
        else {
            Guthaben::add($result['guthaben'], 'wcf.guthaben.statement.remove.text', $result['logID'], '', $this->user);
        }

        
		$this->executed();
		
		// forward to list page
		HeaderUtil::redirect('index.php?page=GuthabenStatement&userID='.$this->userID.'&packageID='.PACKAGE_ID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>