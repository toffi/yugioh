<?php
// wcf imports
require_once(WCF_DIR.'lib/system/event/EventListener.class.php');

class EcpHeaderListener implements EventListener {
	public $templateName = 'ecpHeaderMenuItem';

	public function execute($eventObj, $className, $eventName){
        if(!WCF::getUser()->getPermission('mod.ecp.canSeeECP')) return;

        WCF::getTPL()->append('additionalUserMenuItems', WCF::getTPL()->fetch($this->templateName));
	}
}
?>