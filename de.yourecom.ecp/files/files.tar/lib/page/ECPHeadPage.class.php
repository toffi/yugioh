<?php
$this->headerMenuItems = array();
$sql = "SELECT	events_button.eventID, events.current_gameday, events.name_abbreviation
		FROM		events_button
		LEFT JOIN   events
		  ON (events.id=events_button.eventID)
		WHERE events_button.1Button = '1' || events_button.2Button = '1' || events_button.3Button = '1' || events_button.4Button = '1' || events_button.5Button = '1'";
$result = WCF::getDB()->sendQuery($sql);
while ($row = WCF::getDB()->fetchArray($result)) {
    $this->headerMenuItems[] = $row;
}

WCF::getTPL()->assign(array(
    'headerMenuItems' => $this->headerMenuItems
));
?>